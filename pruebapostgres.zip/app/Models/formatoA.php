<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class formatoA extends Model
{

    protected $fillable = [
        'inaidempleado',
        'inaruido',
        'inafrio',
        'inacalor',
        'inaairefresco',
        'inaluz',
        'inacomodo',
        'inasustanquimicas',
        'inaesfuerzofisico',
        'inaequiposcomodos',
        'inaanimalesplantas',
        'inapreoaccidente',
        'inalugarlimpio',
        'inatiempoadicional',
        'inaalcanzatiempo',
        'inatrabajasinparar',
        'inaesfuerzomental',
        'inaexigeconcentrado',
        'inaexigememoria',
        'inadesiciondificiles',
        'inaexigeasuntos',
        'inapqnosdetalles',
        'inaresponcosasvalor',
        'inarespondinero',
        'inareponderotros',
        'inaresponarea',
        'inareponsalud',
        'inaordecontradic',
        'inahacerinnecesaria',
        'inapasarnormas',
        'inamaspracticas',
        'inatrabajodenoche',
        'inapausas',
        'inatrabajodiadesca',
        'inaencasapiensotra',
        'inadiscutofamilia',
        'inaasuntosencasa',
        'inapocotiempofami',
        'inapermitehabilidad',
        'inapermiteconocimi',
        'inapermiteaprender',
        'inamiscapacidades',
        'inapausasnecesito',
        'inatrabajodiario',
        'inadecivelocidad',
        'inacambiarordenact',
        'inaatenderasunpers',
    
    ];

    protected $table = 'intralaboral_a';
    protected $primaryKey = 'inaid';
    public $timestamps = false;
}

