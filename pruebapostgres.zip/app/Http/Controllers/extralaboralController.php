<?php

namespace App\Http\Controllers;
use App\Models\extralaboral;
use Illuminate\Http\Request;

class extralaboralController extends Controller
{
        /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return extralaboral::all();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        return extralaboral::create($request->all());
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $extid)
    {
        $cl = extralaboral::findOrfail($extid);
        $cl -> extidempleado= $request ->extidempleado;
        $cl -> extfaciltransporte= $request ->extfaciltransporte;
        $cl -> extvariostransporte= $request ->extvariostransporte;
        $cl -> extmuchotiemviaje= $request ->extmuchotiemviaje;
        $cl -> exttranscomodo= $request ->exttranscomodo;
        $cl -> extzonasegura= $request ->extzonasegura;
        $cl -> extzonadelincuencia= $request ->extzonadelincuencia;
        $cl -> extfacilcmedico= $request ->extfacilcmedico;
        $cl -> extbuenasvias= $request ->extbuenasvias;
        $cl -> extcercatransporte= $request ->extcercatransporte;
        $cl -> extcondicvivienda= $request ->extcondicvivienda;
        $cl -> extagualuz= $request ->extagualuz;
        $cl -> extpermdescanzar= $request ->extpermdescanzar;
        $cl -> extviviendacomoda= $request ->extviviendacomoda;
        $cl -> exttiemporecreo= $request ->exttiemporecreo;
        $cl -> exttiempodescanzo= $request ->exttiempodescanzo;
        $cl -> exttiempopersonal= $request ->exttiempopersonal;
        $cl -> exttiempofamilia= $request ->exttiempofamilia;
        $cl -> extbuenacomunica= $request ->extbuenacomunica;
        $cl -> extrelacionamigos= $request ->extrelacionamigos;
        $cl -> extconversoperson= $request ->extconversoperson;
        $cl -> extamigosescuchan= $request ->extamigosescuchan;
        $cl -> extapoyofamiliar= $request ->extapoyofamiliar;
        $cl -> exthabloconperso= $request ->exthabloconperso;
        $cl -> extproblemfamiliar= $request ->extproblemfamiliar;
        $cl -> extrelacionfamiliar= $request ->extrelacionfamiliar;
        $cl -> extquitanenergia= $request ->extquitanenergia;
        $cl -> extresolveamistosa= $request ->extresolveamistosa;
        $cl -> extafectrelacionestra= $request ->extafectrelacionestra;
        $cl -> extdineroalcanza= $request ->extdineroalcanza;
        $cl -> extpresupuesfamilia= $request ->extpresupuesfamilia;
        $cl -> extdeudashogar= $request ->extdeudashogar;
       // $cl -> extfechareg= $request ->extfechareg;
       // $cl -> extfechamod= $request ->extfechamod;
        $cl -> extusuarioreg= $request ->extusuarioreg;


        $cl -> update();
        return $cl;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($extid)
    {
        $cl = extralaboral::findOrfail($extid);
        $cl -> delete();
    }
    public function buscarid($extid)
    {
    $user = extralaboral::where("extidempleado","=",$extid)->get();
       
        return  $user;
    }
}
