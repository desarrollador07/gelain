<?php

namespace App\Http\Controllers;
use App\Models\estres;
use Illuminate\Http\Request;

class estresController extends Controller
{
        /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return estres::all();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        return estres::create($request->all());
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $estid)
    {
        $cl = estres::findOrfail($estid);
        $cl -> estidempleado= $request ->estidempleado;
        $cl -> estdolorcuello= $request ->estdolorcuello;
        $cl -> estprobgastrico= $request ->estprobgastrico;
        $cl -> estprobrespira= $request ->estprobrespira;
        $cl -> estdolorcabeza= $request ->estdolorcabeza;
        $cl -> esttrastsueno= $request ->esttrastsueno;
        $cl -> estpalpitacion= $request ->estpalpitacion;
        $cl -> estcamapetito= $request ->estcamapetito;
        $cl -> estprobgenital= $request ->estprobgenital;
        $cl -> estdiffamiliar= $request ->estdiffamiliar;
        $cl -> estdifquieto= $request ->estdifquieto;
        $cl -> estdifpersonas= $request ->estdifpersonas;
        $cl -> estsensaislami= $request ->estsensaislami;
        $cl -> estsobrecarga= $request ->estsobrecarga;
        $cl -> estdifconcentrar= $request ->estdifconcentrar;
        $cl -> estaumentaccid= $request ->estaumentaccid;
        $cl -> estsentfrustra= $request ->estsentfrustra;
        $cl -> estcansancio= $request ->estcansancio;
        $cl -> estdismrendimie= $request ->estdismrendimie;
        $cl -> estdeseonotrab= $request ->estdeseonotrab;
        $cl -> estpocointeres= $request ->estpocointeres;
        $cl -> estdifdecisiones= $request ->estdifdecisiones;
        $cl -> estcambioempleo= $request ->estcambioempleo;
        $cl -> estsentisoledad= $request ->estsentisoledad;
        $cl -> estsentinegativo= $request ->estsentinegativo;
        $cl -> estconsdrogas= $request ->estconsdrogas;
        $cl -> estsentinosirve= $request ->estsentinosirve;
        $cl -> estconsucigarri= $request ->estconsucigarri;
        $cl -> estperdirazon= $request ->estperdirazon;
        $cl -> estcomprigido= $request ->estcomprigido;
        $cl -> estsensproblem= $request ->estsensproblem;
       // $cl -> estfechareg= $request ->estfechareg;
       // $cl -> estfechamod= $request ->estfechamod;
        $cl -> estusuarioreg= $request ->estusuarioreg;


        $cl -> update();
        return $cl;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($estid)
    {
        $cl = estres::findOrfail($estid);
        $cl -> delete();
    }

    public function buscarid($estid)
    {
    $user = estres::where("estidempleado","=",$estid)->get();
       
        return  $user;
    }
}
