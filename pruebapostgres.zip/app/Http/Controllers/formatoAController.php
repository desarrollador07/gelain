<?php

namespace App\Http\Controllers;
use App\Models\formatoA;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;


class formatoAController extends Controller
{
        /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return formatoA::all();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        return formatoA::create($request->all());
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $inaid)
    {
        $cl = formatoA::findOrfail($inaid);
        $cl -> inaidempleado= $request ->inaidempleado;
        $cl -> inaruido= $request ->inaruido;
        $cl -> inafrio= $request ->inafrio;
        $cl -> inacalor= $request ->inacalor;
        $cl -> inaairefresco= $request ->inaairefresco;
        $cl -> inaluz= $request ->inaluz;
        $cl -> inacomodo= $request ->inacomodo;
        $cl -> inasustanquimicas= $request ->inasustanquimicas;
        $cl -> inaesfuerzofisico= $request ->inaesfuerzofisico;
        $cl -> inaequiposcomodos= $request ->inaequiposcomodos;
        $cl -> inaanimalesplantas= $request ->inaanimalesplantas;
        $cl -> inapreoaccidente= $request ->inapreoaccidente;
        $cl -> inalugarlimpio= $request ->inalugarlimpio;
        $cl -> inatiempoadicional= $request ->inatiempoadicional;
        $cl -> inaalcanzatiempo= $request ->inaalcanzatiempo;
        $cl -> inatrabajasinparar= $request ->inatrabajasinparar;
        $cl -> inaesfuerzomental= $request ->inaesfuerzomental;
        $cl -> inaexigeconcentrado= $request ->inaexigeconcentrado;
        $cl -> inaexigememoria= $request ->inaexigememoria;
        $cl -> inadesiciondificiles= $request ->inadesiciondificiles;
        $cl -> inaexigeasuntos= $request ->inaexigeasuntos;
        $cl -> inapqnosdetalles= $request ->inapqnosdetalles;
        $cl -> inaresponcosasvalor= $request ->inaresponcosasvalor;
        $cl -> inarespondinero= $request ->inarespondinero;
        $cl -> inareponderotros= $request ->inareponderotros;
        $cl -> inaresponarea= $request ->inaresponarea;
        $cl -> inareponsalud= $request ->inareponsalud;
        $cl -> inaordecontradic= $request ->inaordecontradic;
        $cl -> inahacerinnecesaria= $request ->inahacerinnecesaria;
        $cl -> inapasarnormas= $request ->inapasarnormas;
        $cl -> inamaspracticas= $request ->inamaspracticas;
        $cl -> inatrabajodenoche= $request ->inatrabajodenoche;
        $cl -> inapausas= $request ->inapausas;
        $cl -> inatrabajodiadesca= $request ->inatrabajodiadesca;
        $cl -> inafinsemdesc= $request -> inafinsemdesc;
        $cl -> inaencasapiensotra= $request ->inaencasapiensotra;
        $cl -> inadiscutofamilia= $request ->inadiscutofamilia;
        $cl -> inaasuntosencasa= $request ->inaasuntosencasa;
        $cl -> inapocotiempofami= $request ->inapocotiempofami;
        $cl -> inapermitehabilidad= $request ->inapermitehabilidad;
        $cl -> inapermiteconocimi= $request ->inapermiteconocimi;
        $cl -> inapermiteaprender= $request ->inapermiteaprender;
        $cl -> inamiscapacidades= $request ->inamiscapacidades;
        $cl -> inapausasnecesito= $request ->inapausasnecesito;
        $cl -> inatrabajodiario= $request ->inatrabajodiario;
        $cl -> inadecivelocidad= $request ->inadecivelocidad;
        $cl -> inacambiarordenact= $request ->inacambiarordenact;
        $cl -> inaatenderasunpers= $request ->inaatenderasunpers;
      $cl -> inacambiosbeneficio= $request ->inacambiosbeneficio;
      $cl -> inaexplicancambios= $request ->inaexplicancambios;
      $cl -> inapuedodarsugeren= $request ->inapuedodarsugeren;
      $cl -> inaencuentamisideas= $request ->inaencuentamisideas;
      $cl -> inacambiosdificultan= $request ->inacambiosdificultan;
      $cl -> inaclaridadfunciones= $request ->inaclaridadfunciones;
      $cl -> inadecisionesatomar= $request ->inadecisionesatomar;
      $cl -> inaresultadoslograr= $request ->inaresultadoslograr;
      $cl -> inaefectoenempresa= $request ->inaefectoenempresa;
      $cl -> inaexplicanobjetivos= $request ->inaexplicanobjetivos;
      $cl -> inaorientaciontraba= $request ->inaorientaciontraba;
      $cl -> inaresolverasuntos= $request ->inaresolverasuntos;
      $cl -> inaasiscapacitacion= $request ->inaasiscapacitacion;
      $cl -> inarecibocapacitaci= $request ->inarecibocapacitaci;
      $cl -> inarecibocapaciayuda= $request ->inarecibocapaciayuda;
      $cl -> inajefeintrucciones= $request ->inajefeintrucciones;
      $cl -> inajefeayudaorganiz= $request ->inajefeayudaorganiz;
      $cl -> inajefemispuntosvist= $request ->inajefemispuntosvist;
      $cl -> inajefeanima= $request ->inajefeanima;
      $cl -> inajefedistribuye= $request ->inajefedistribuye;
      $cl -> inajefecomunica= $request ->inajefecomunica;
      $cl -> inajefeorienracion= $request ->inajefeorienracion;
      $cl -> inajefeayudaprogres= $request ->inajefeayudaprogres;
      $cl -> inajefeayudasentime= $request ->inajefeayudasentime;
      $cl -> inajefesolucionar= $request ->inajefesolucionar;
      $cl -> inajefeconfio= $request ->inajefeconfio;
      $cl -> inajefeescucha= $request ->inajefeescucha;
      $cl -> inajefeapoyo= $request ->inajefeapoyo;
      $cl -> inaagradaambiente= $request ->inaagradaambiente;
      $cl -> inagruporespeto= $request ->inagruporespeto;
      $cl -> inaconfiocompaneros= $request ->inaconfiocompaneros;
      $cl -> inaagustocompaneros= $request ->inaagustocompaneros;
      $cl -> inagrupomaltrata= $request ->inagrupomaltrata;
      $cl -> inasolucionacompa= $request ->inasolucionacompa;
      $cl -> inaintegraciongrp= $request ->inaintegraciongrp;
      $cl -> inagrupounido= $request ->inagrupounido;
      $cl -> inasentirpartegrupo= $request ->inasentirpartegrupo;
      $cl -> inatrabajogrupo= $request ->inatrabajogrupo;
      $cl -> inagrupodeacuerdo= $request ->inagrupodeacuerdo;
      $cl -> inagrupoayuda= $request ->inagrupoayuda;
      $cl -> inaapoyounootros= $request ->inaapoyounootros;
      $cl -> inaescuchanproble= $request ->inaescuchanproble;
      $cl -> inainfhagobien= $request ->inainfhagobien;
      $cl -> inainfmejorar= $request ->inainfmejorar;
      $cl -> inainfrendimiento= $request ->inainfrendimiento;
      $cl -> inaevaluantrabajo= $request ->inaevaluantrabajo;
      $cl -> inainfatiempomejora= $request ->inainfatiempomejora;
      $cl -> inaempconfiantrab= $request ->inaempconfiantrab;
      $cl -> inaemppaganatiempo= $request ->inaemppaganatiempo;
      $cl -> inapagoofrecido= $request ->inapagoofrecido;
      $cl -> inapagomerezco= $request ->inapagomerezco;
      $cl -> inaposibprogresar= $request ->inaposibprogresar;
      $cl -> inahacerbienprog= $request ->inahacerbienprog;
      $cl -> inaempbienestartrab= $request ->inaempbienestartrab;
      $cl -> inatrabajoestable= $request ->inatrabajoestable;
      $cl -> inatrabsentirbien= $request ->inatrabsentirbien;
      $cl -> inasientoorgullo= $request ->inasientoorgullo;
      $cl -> inahablobienempres= $request ->inahablobienempres;
      $cl -> inaatencionausuarios = $request ->inaatencionausuarios;
      $cl -> inausuenojados= $request ->inausuenojados;
      $cl -> inausupreocupados= $request ->inausupreocupados;
      $cl -> inausutristes= $request ->inausutristes;
      $cl -> inausuenfermos= $request ->inausuenfermos;
      $cl -> inausuneceayuda= $request ->inausuneceayuda;
      $cl -> inausumemaltratan= $request ->inausumemaltratan;
      $cl -> inaususentimidistin= $request ->inaususentimidistin;
      $cl -> inasituaviolencia= $request ->inasituaviolencia;
      $cl -> inaexigedolorosas= $request ->inaexigedolorosas;
      $cl -> inasoyjefe = $request ->inasoyjefe;
      $cl -> inacomuntarde= $request ->inacomuntarde;
      $cl -> inairrespetuosos= $request ->inairrespetuosos;
      $cl -> inadificorganiza= $request ->inadificorganiza;
      $cl -> inaguardansilencio= $request ->inaguardansilencio;
      $cl -> inadificlogro= $request ->inadificlogro;
      $cl -> inainforirrespet= $request ->inainforirrespet;
      $cl -> inapocacooperacio= $request ->inapocacooperacio;
      $cl -> inapocodesempeno= $request ->inapocodesempeno;
      $cl -> inacolabignoran= $request ->inacolabignoran;

        $cl -> update();
        return $cl;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($inaid)
    {
        $cl = formatoA::findOrfail($inaid);
        $cl -> delete();
    }
    public function buscarid($inaid)
    {
    $user = formatoA::where("inaidempleado","=",$inaid)->get();
       
        return  $user;
    }

    public function CLiderazgo()
    {
        $result = formatoA::select([
          'inajefeintrucciones',
          'inajefeayudaorganiz',
          'inajefemispuntosvist',
          'inajefeanima',
          'inajefedistribuye',
          'inajefecomunica',
          'inajefeorienracion',
          'inajefeayudaprogres',
          'inajefeayudasentime',
          'inajefesolucionar',
          'inajefeconfio',
          'inajefeescucha',
          'inajefeapoyo'
        ])
        ->get();
        
        return $result;
    }

    public function totalRango()
    {
      $res = formatoA::select(

        'inajefeintrucciones',
        'inajefeayudaorganiz',
        'inajefemispuntosvist',
        'inajefeanima',
        'inajefedistribuye',
        'inajefecomunica',
        'inajefeorienracion',
        'inajefeayudaprogres',
        'inajefeayudasentime',
        'inajefesolucionar',
        'inajefeconfio',
        'inajefeescucha',
        'inajefeapoyo',
        
        DB::RAW('SUM(inajefeintrucciones) as inajefeintrucciones'))
        
        ->get();
        return $res;
    }

    public function RSTrabajo()
    {
        $result = formatoA::select([
            'inaagradaambiente',
            'inagruporespeto',
            'inaconfiocompaneros',
            'inaagustocompaneros',
            'inagrupomaltrata',
            'inasolucionacompa',
            'inaintegraciongrp',
            'inagrupounido',
            'inasentirpartegrupo',
            'inatrabajogrupo',
            'inagrupodeacuerdo',
            'inagrupoayuda',
            'inaapoyounootros',
            'inaescuchanproble',
        ])
        ->get();
        
        return $result;
    }
    /* --------- */
    public function RDesempeño()
    {
        $result = formatoA::select([
            'inainfhagobien',
            'inainfmejorar',
            'inainfrendimiento',
            'inaevaluantrabajo',
            'inainfatiempomejora',
        ])
        ->get();
        
        return $result;
    }
    public function RColaboradores()
    {
        $result = formatoA::select([
            'inacomuntarde',
            'inairrespetuosos',
            'inadificorganiza',
            'inaguardansilencio',
            'inadificlogro',
            'inainforirrespet',
            'inapocacooperacio',
            'inapocodesempeno',
            'inacolabignoran'
        ])
        ->get();
        
        return $result;
    }
    public function ClaridadRol()
    {
        $result = formatoA::select([
            'inaclaridadfunciones',
            'inadecisionesatomar',
            'inaresultadoslograr',
            'inaefectoenempresa',
            'inaexplicanobjetivos',
            'inaorientaciontraba',
            'inaresolverasuntos',
        ])
        ->get();
        
        return $result;
    }

    public function Capacitacion()
    {
        $result = formatoA::select([
            'inaasiscapacitacion',
            'inarecibocapacitaci',
            'inarecibocapaciayuda',
        ])
        ->get();
        
        return $result;
    }

    public function PMCambio()
    {
        $result = formatoA::select([
            'inacambiosbeneficio',
            'inaexplicancambios',
            'inapuedodarsugeren',
            'inaencuentamisideas',
        ])
        ->get();
        
        return $result;
    }

    public function Oportunidades()
    {
        $result = formatoA::select([
            'inapermitehabilidad',
            'inapermiteconocimi',
            'inapermiteaprender',
            'inamiscapacidades',
        ])
        ->get();
        
        return $result;
    }

    public function ConAutoTrabajo()
    {
        $result = formatoA::select([
            'inatrabajodiario',
            'inadecivelocidad',
            'inacambiarordenact',
        ])
        ->get();
        
        return $result;
    }

    public function DemandasAmb()
    {
        $result = formatoA::select([
            'inaruido',
            'inafrio',
            'inacalor',
            'inaairefresco',
            'inaluz',
            'inacomodo',
            'inasustanquimicas',
            'inaesfuerzofisico',
            'inaequiposcomodos',
            'inaanimalesplantas',
            'inapreoaccidente',
            'inalugarlimpio',
        ])
        ->get();
        
        return $result;
    }

    public function DemandasEmocionales()
    {
        $result = formatoA::select([
            'inausuenojados',
            'inausupreocupados',
            'inausutristes',
            'inausuenfermos',
            'inausuneceayuda',
            'inausumemaltratan',
            'inaususentimidistin',
            'inasituaviolencia',
            'inaexigedolorosas',
        ])
        ->get();
        
        return $result;
    }
    public function DemandasCuantitativas()
    {
        $result = formatoA::select([
            'inatiempoadicional',
            'inaalcanzatiempo',
            'inatrabajasinparar',
            'inapausas',
            'inapausasnecesito',
            'inaatenderasunpers',
        ])
        ->get();
        
        return $result;
    }

    public function InfluenciaTrabajo()
    {
        $result = formatoA::select([
            'inaencasapiensotra',
            'inadiscutofamilia',
            'inaasuntosencasa',
            'inapocotiempofami',
        ])
        ->get();
        
        return $result;
    }

    public function ExigenciasResponsabilidad()
    {
        $result = formatoA::select([
            'inadesiciondificiles',
            'inaresponcosasvalor',
            'inarespondinero',
            'inareponderotros',
            'inaresponarea',
            'inareponsalud',
        ])
        ->get();
        
        return $result;
    }

    public function DemandasCargaMental()
    {
        $result = formatoA::select([
            'inaesfuerzomental',
            'inaexigeconcentrado',
            'inaexigememoria',
            'inaexigeasuntos',
            'inapqnosdetalles',
        ])
        ->get();
        
        return $result;
    }
    
    public function ConsistenciasRol()
    {
        $result = formatoA::select([
            'inaordecontradic',
            'inahacerinnecesaria',
            'inapasarnormas',
            'inamaspracticas',
            'inacambiosdificultan',
        ])
        ->get();
        
        return $result;
    }

    public function DemandasJornadaTrabajo()
    {
        $result = formatoA::select([
            'inatrabajodenoche',
            'inatrabajodiadesca',
            'inafinsemdesc',
        ])
        ->get();
        
        return $result;
    }

    public function RecompensasDerivadas()
    {
        $result = formatoA::select([
            'inaempconfiantrab',
            'inatrabajoestable',
            'inatrabsentirbien',
            'inasientoorgullo',
            'inahablobienempres',
        ])
        ->get();
        
        return $result;
    }

    public function ReconocimientoCompetencia()
    {
        $result = formatoA::select([
            'inaemppaganatiempo',
            'inapagoofrecido',
            'inapagomerezco',
            'inaposibprogresar',
            'inahacerbienprog',
            'inaempbienestartrab',
        ])
        ->get();
        
        return $result;
    }
    

   
}
