<?php

namespace App\Http\Controllers;
use App\Models\formatoB;
use Illuminate\Http\Request;

class formatoBController extends Controller
{
        /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return formatoB::all();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        return formatoB::create($request->all());
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $inaid)
    {
        $cl = formatoB::findOrfail($inaid);
        
        $cl -> inbidempleado= $request ->inbidempleado;
        $cl -> inbruido= $request ->inbruido;
        $cl -> inbfrio= $request ->inbfrio;
        $cl -> inbcalor= $request ->inbcalor;
        $cl -> inbairefresco= $request ->inbairefresco;
        $cl -> inbluz= $request ->inbluz;
        $cl -> inbcomodo= $request ->inbcomodo;
        $cl -> inbsustanquimicas= $request ->inbsustanquimicas;
        $cl -> inbesfuerzofisico= $request ->inbesfuerzofisico;
        $cl -> inbequiposcomodos= $request ->inbequiposcomodos;
        $cl -> inbanimalesplantas= $request ->inbanimalesplantas;
        $cl -> inbpreoaccidente= $request ->inbpreoaccidente;
        $cl -> inblugarlimpio= $request ->inblugarlimpio;
        $cl -> inbtiempoadicional= $request ->inbtiempoadicional;
        $cl -> inbalcanzatiempo= $request ->inbalcanzatiempo;
        $cl -> inbtrabajasinparar= $request ->inbtrabajasinparar;
        $cl -> inbesfuerzomental= $request ->inbesfuerzomental;
        $cl -> inbexigeconcentrado= $request ->inbexigeconcentrado;
        $cl -> inbexigememoria= $request ->inbexigememoria;
        $cl -> inbhacercalculos= $request ->inbhacercalculos;
        $cl -> inbpqnosdetalles= $request ->inbpqnosdetalles;
        $cl -> inbtrabajonoche= $request ->inbtrabajonoche;
        $cl -> inbtomarpausas= $request ->inbtomarpausas;
        $cl -> inbtrabajodiadesca= $request ->inbtrabajodiadesca;
        $cl -> inbfinsemdesc= $request ->inbfinsemdesc;
        $cl -> inbencasapiensotra= $request ->inbencasapiensotra;
        $cl -> inbdiscutofamilia= $request ->inbdiscutofamilia;
        $cl -> inbasuntosencasa= $request ->inbasuntosencasa;
        $cl -> inbpocotiempofami= $request ->inbpocotiempofami;
        $cl -> inbhacercosasnuevas= $request ->inbhacercosasnuevas;
        $cl -> inbpermitehabilidad= $request ->inbpermitehabilidad;
        $cl -> inbpermiteconocimi= $request ->inbpermiteconocimi;
        $cl -> inbpermiteaprender= $request ->inbpermiteaprender;
        $cl -> inbpausasnecesito= $request ->inbpausasnecesito;
        $cl -> inbtrabajodiario= $request ->inbtrabajodiario;
        $cl -> inbdecivelocidad= $request ->inbdecivelocidad;
        $cl -> inbcambiarordenact= $request ->inbcambiarordenact;
        $cl -> inbatenderasunpers= $request ->inbatenderasunpers;
        $cl -> inbexplicancambios= $request ->inbexplicancambios;
        $cl -> inbpuedodarsugeren= $request ->inbpuedodarsugeren;
        $cl -> inbencuentamisideas= $request ->inbencuentamisideas;
        $cl -> inbclaridadfunciones= $request ->inbclaridadfunciones;
        $cl -> inbdecisionesatomar= $request ->inbdecisionesatomar;
        $cl -> inbresultadoslograr= $request ->inbresultadoslograr;
        $cl -> inbexplicanobjetivos= $request ->inbexplicanobjetivos;
        $cl -> inbinfquienresolver= $request ->inbinfquienresolver;
        $cl -> inbasiscapacitacion= $request ->inbasiscapacitacion;
        $cl -> inbrecibocapacitaci= $request ->inbrecibocapacitaci;
        $cl -> inbrecibocapaciayuda= $request ->inbrecibocapaciayuda;
        $cl -> inbjefeayudaorganiz= $request ->inbjefeayudaorganiz;
        $cl -> inbjefemispuntosvist= $request ->inbjefemispuntosvist;
        $cl -> inbjefeanima= $request ->inbjefeanima;
        $cl -> inbjefedistribuye= $request ->inbjefedistribuye;
        $cl -> inbjefecomunica= $request ->inbjefecomunica;
        $cl -> inbjefeorienracion= $request ->inbjefeorienracion;
        $cl -> inbjefeayudaprogres= $request ->inbjefeayudaprogres;
        $cl -> inbjefeayudasentime= $request ->inbjefeayudasentime;
        $cl -> inbjefesolucionar= $request ->inbjefesolucionar;
        $cl -> inbjeferespeto= $request ->inbjeferespeto;
        $cl -> inbjefeconfio= $request ->inbjefeconfio;
        $cl -> inbjefeescucha= $request ->inbjefeescucha;
        $cl -> inbjefeapoyo= $request ->inbjefeapoyo;
        $cl -> inbagradaambiente= $request ->inbagradaambiente;
        $cl -> inbgruporespeto= $request ->inbgruporespeto;
        $cl -> inbconfiocompaneros= $request ->inbconfiocompaneros;
        $cl -> inbagustocompaneros= $request ->inbagustocompaneros;
        $cl -> inbgrupomaltrata= $request ->inbgrupomaltrata;
        $cl -> inbsolucionacompa= $request ->inbsolucionacompa;
        $cl -> inbgrupounido= $request ->inbgrupounido;
        $cl -> inbtrabajogrupo= $request ->inbtrabajogrupo;
        $cl -> inbgrupodeacuerdo= $request ->inbgrupodeacuerdo;
        $cl -> inbgrupoayuda= $request ->inbgrupoayuda;
        $cl -> inbapoyounootros= $request ->inbapoyounootros;
        $cl -> inbescuchanproble= $request ->inbescuchanproble;
        $cl -> inbinfhagobien= $request ->inbinfhagobien;
        $cl -> inbinfmejorar= $request ->inbinfmejorar;
        $cl -> inbinfrendimiento= $request ->inbinfrendimiento;
        $cl -> inbevaluantrabajo= $request ->inbevaluantrabajo;
        $cl -> inbinfatiempomejora= $request ->inbinfatiempomejora;
        $cl -> inbemppaganatiempo= $request ->inbemppaganatiempo;
        $cl -> inbpagoofrecido= $request ->inbpagoofrecido;
        $cl -> inbpagomerezco= $request ->inbpagomerezco;
        $cl -> inbposibprogresar= $request ->inbposibprogresar;
        $cl -> inbhacerbienprog= $request ->inbhacerbienprog;
        $cl -> inbempbienestartrab= $request ->inbempbienestartrab;
        $cl -> inbtrabajoestable= $request ->inbtrabajoestable;
        $cl -> inbtrabsentirbien= $request ->inbtrabsentirbien;
        $cl -> inbsientoorgullo= $request ->inbsientoorgullo;
        $cl -> inbhablobienempres= $request ->inbhablobienempres;
        $cl -> inbatencionausuarios= $request ->inbatencionausuarios;
        $cl -> inbusuenojados= $request ->inbusuenojados;
        $cl -> inbusupreocupados= $request ->inbusupreocupados;
        $cl -> inbusutristes= $request ->inbusutristes;
        $cl -> inbusuenfermos= $request ->inbusuenfermos;
        $cl -> inbusuneceayuda= $request ->inbusuneceayuda;
        $cl -> inbusumemaltratan= $request ->inbusumemaltratan;
        $cl -> inbsituaviolencia= $request ->inbsituaviolencia;
        $cl -> inbexigedolorosas= $request ->inbexigedolorosas;
        $cl -> inbexpretristeza= $request ->inbexpretristeza; 


        $cl -> update();
        return $cl;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($inaid)
    {
        $cl = formatoB::findOrfail($inaid);
        $cl -> delete();
    }
    
        public function buscarid($inaid)
    {
    $user = formatoB::where("inbidempleado","=",$inaid)->get();
       
        return  $user;
    }
}