<?php

use App\Http\Controllers\testController;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;



 Route::get('migration', function () {
    Artisan::call('migrate');
 });


 Auth::routes();
 Route::get('all', 'testController@index');
 Route::post('create', 'testController@store');
 Route::put('update/{id}', 'testController@update');
 Route::delete('delete/{id}', 'testController@destroy');
 
 Route::get('allp', 'pruebaController@index');
 Route::post('createp', 'pruebaController@store');
 Route::put('updatep/{id}', 'pruebaController@update');
 Route::delete('deletep/{id}', 'pruebaController@destroy');
 
 Route::get('allEmpresa', 'empresaController@index');
 Route::post('createEmpresa', 'empresaController@store');
 Route::put('updateEmpresa/{id}', 'empresaController@update');
 Route::delete('deleteEmpresa/{id}', 'empresaController@destroy');
 
 Route::get('allEmpleados', 'empleadosController@index');
 Route::get('allEmpleadosReportes', 'empleadosController@indexReportes');
 Route::post('createEmpleados', 'empleadosController@store');
 Route::put('updateEmpleados/{id}', 'empleadosController@update');
 Route::delete('deleteEmpleados/{id}', 'empleadosController@destroy');
 
 Route::get('allArea', 'areaController@index');
 Route::post('createArea', 'areaController@store');
 Route::put('updateArea/{id}', 'areaController@update');
 Route::delete('deleteArea/{id}', 'areaController@destroy');
 Route::get('getideArea/{idEmp}', 'areaController@buscarid');
 
 
 Route::get('allformatoA', 'formatoAController@index');
 Route::post('createformatoA', 'formatoAController@store');
 Route::put('updateformatoA/{id}', 'formatoAController@update');
 Route::delete('deleteformatoA/{id}', 'formatoAController@destroy');
 Route::get('getideForA/{idEmp}', 'formatoAController@buscarid');
 
 Route::get('allformatoB', 'formatoBController@index');
 Route::post('createformatoB', 'formatoBController@store');
 Route::put('updateformatoB/{id}', 'formatoBController@update');
 Route::delete('deleteformatoB/{id}', 'formatoBController@destroy');
 Route::get('getideForB/{idEmp}', 'formatoBController@buscarid');
 
 Route::get('allestres', 'estresController@index');
 Route::post('createestres', 'estresController@store');
 Route::put('updateestres/{id}', 'estresController@update');
 Route::delete('deleteestres/{id}', 'estresController@destroy');
 Route::get('getideEstres/{idEmp}', 'estresController@buscarid');
 
 Route::get('allextra', 'extralaboralController@index');
 Route::post('createextra', 'extralaboralController@store');
 Route::put('updateextra/{id}', 'extralaboralController@update');
 Route::delete('deleteextra/{id}', 'extralaboralController@destroy');
 Route::get('getideExtra/{idEmp}', 'extralaboralController@buscarid');